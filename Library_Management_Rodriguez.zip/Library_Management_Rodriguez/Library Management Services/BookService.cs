﻿namespace Library_Management_Services
{
    public class BookService
    {
        private readonly ICollection<BookListViewModel>
    }
}
